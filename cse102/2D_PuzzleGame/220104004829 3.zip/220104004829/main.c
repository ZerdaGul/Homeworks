#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define UP 'w'
#define DOWN 's'
#define RIGHT 'd'
#define LEFT 'a'

void part1(int size, int current_i, int current_j, int door_i, int door_j);
int part3(int current_i, int current_j, int door_i, int door_j);
void part2(int size, int current_i, int current_j, int door_i, int door_j);
void part4();

int main(){

printf("'a' = left, 'd' = right, 'w' = up, 's' = down\n "); //at the first of the game, shows the keypads for directions
part4(); //starts the game

}

void part1(int size, int current_i, int current_j, int door_i, int door_j){
    //print the game room to the console
    for(int i=1; i<=((size*2)+1); i++){
        printf("-"); //print upper wall
    }
    printf("\n");

    for(int i=1; i<=size; i++){
        printf("|"); //print left wall
        for(int j=1; j<=size; j++){
            if(i==(current_i) && j==(current_j)){ 
                printf("C|"); //print C to the character's current position
            }
            else if(i==(door_i) && j==(door_j)){ 
                printf("D|"); //print D to the location of the door
            }
            else{
            printf(" |"); //print left wall
            }
        }
        printf("\n");
    }
    for(int i=1; i<=((size*2)+1); i++){
        printf("-"); //print below wall
    }
    printf("\n");
}

int part3(int current_i, int current_j, int door_i, int door_j){
    //this function check whether the character reached the door or not
    int flag= 0;
    if((current_i==door_i) && (current_j==door_j)){
        flag= 1; //if character reach door then flag is 1
    }
    else{
        flag= 0; //if character does not reach the door then flag is 0
    }
    return flag; //function returns flag
}

void part2(int size, int current_i, int current_j, int door_i, int door_j){

    char direction, newline, character_check=0; //character_check check whether wasd or another input has entered.
    int hci, hcj, hdi, hdj; //these are the variables to store previous coordinates
    int moves=0, flag=0; //moves for the number of movements, flag is for 1 when character reach the door.
    part1(size, current_i, current_j, door_i, door_j); //when game starts, we create room with part1
while(flag==0){ //unless character reach the door, we get direction from the user
    character_check=0;
    scanf(" %c", &direction);    //get direction from user
    scanf("%c", &newline);      //we check that if user push enter or try to use diagonal move
    //let the hold values store the coordinates
    hci= current_i;
    hcj= current_j;
    hdi= door_i;
    hdj= door_j;

    if(newline=='\n'){ // if user do not use diagonal move then continue
        //respect to the direction, change coordinate
        switch(direction){
            case LEFT :
                current_j--;
                break;
            case RIGHT :
                current_j++;
                break;
            case UP :
                current_i--;
                break;
            case DOWN :
                current_i++;
                break;
            default:
            	character_check=1; //says wasd not entered
            	break;
        }

        if(character_check==0){ //if input is w,a,s or d, try to move
            //check whether the character reach the door or not, if it reached then flag will be 1
            flag= part3(current_i, current_j, door_i, door_j);

            if(flag==1){ //if character reach door then player win
                printf("You reached the door and win!\n");
                moves++; //increase the number of movements
                printf("Number of moves: %d\n\n", moves); //print number of movements
                part4(); //call the menu function to ask user what to do
            }
            else if(current_i==0 || current_i==(size+1) || current_j==0 || current_j==(size+1)){
                //if character hits the walls then make the coordinates same with previous coordinates again.
                printf("You hit the wall. Choose another direction.\n");
                current_i = hci;
                current_j = hcj;
                door_i = hdi;
                door_j = hdj;

            }
            else{ //if character does not reach door or not hit the walls, call part1 function to show the room after movement is happened.
                part1(size, current_i, current_j, door_i, door_j);
                moves++; //increase number of movements
            }
        }
        else{   //if input is something other than w,a,s,d, print error message.
            printf("Invalid input.\n");
        }
    }
    else{   //if user try to move diagonal then print error message
        printf("Invalid input.\n");
    }
}

}

void part4(){

    char option;
    int size, current_i, current_j, door_i, door_j;
    int again=1;

    while(again==1){ //when user select 2. Help option or enter a character other then "1,2,3", while loop continues to show menu again
        again=0;
        //print the menu
        printf("Welcome to the 2D puzzle game!\n");
        printf("1. New Game\n");
        printf("2. Help\n");
        printf("3. Exit\n\n");

        printf("Enter the choice: ");
        scanf(" %c", &option); //get the choice of menu from the user

        switch(option){
            case '1':
                //when user starts the new game, get size value from the user
                printf("\nEnter the size of the room: ");
                scanf("%d", &size);
                srand(time(NULL)); //time feeds rand function
                //find randomly selected coordinates 
                current_i= (rand()%size)+1;
                current_j= (rand()%size)+1;
                door_i= (rand()%size)+1;
                door_j= (rand()%size)+1;
                part2(size, current_i, current_j, door_i, door_j); //call part2 function make user play the game
                break;
            case '2':
                //2. Help option shows the rules of the game 
                printf("\nRules:\n");
                printf("The character is able to move one space in any of the four cardinal directions: up, down, left, and right. Diagonal moves are not allowed.\nThe user will input their desired move using the following keys: 'a' for left, 'd' for right, 'w' for up, and 's' for down.\nThe game will prompt the user for a new move after each move is made until the game is over.\nIf  the  character  attempts  to  move  through  a  wall,  a  warning  message will  be  displayed.\nThe game ends when the character reaches the door, and a message will be displayed to notify the user that the game is over and how many moves were made during the game.\n\n");
                again=1; //when user select 2. Help, again is set to 1 so while loop continue and ask for the option in menu again
                break;
            case '3':
                //exit option make the user quit the game
                printf("\nYou quit the game, goodbye!\n");
                break;
            default:
                printf("\nYou should enter 1,2 or 3.\n\n");
                again=1;    //when user select something different then 1,2,3 menu will be shown again.
                break;
        }
    }
}